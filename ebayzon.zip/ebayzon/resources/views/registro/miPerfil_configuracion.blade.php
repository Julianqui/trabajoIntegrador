<?php

$mainTitle = "IDEON - Registro";
$imgUrl = "../imagenes/logo-01.png";

 ?>
