
@section('title', 'IDEON')
@section('imgurl', 'imagenes/logo-01.png')
