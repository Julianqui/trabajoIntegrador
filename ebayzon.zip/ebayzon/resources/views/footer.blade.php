<footer>

<aside class="hor_atencion">
  <h4>Horarios de Atencion:</h4>

<br>
<p>Lunes a Viernes: 6AM a 22PM</p>
<p>Sabado y Domingo: 13PM a 22PM</p>

</aside>

<aside class="siguenos">

<h4>Siguenos en:</h4>

<br>

<ul>

<li><a href="https://twitter.com/tweeter?lang=es" target="_blank"><img src="imagenes/redes-01.png" class="red"></a></li>
<li><a href="http://facebook.com.ar/" target="_blank"><img src="imagenes/redes-02.png" class="red"></a></li>
<li><a href="https://www.google.com.ar/" target="_blank"><img src="imagenes/redes-03.png" class="red"></a></li>
<li><a href="https://www.youtube.com/" target="_blank"><img src="imagenes/redes-04.png" class="red"></a></li>

</ul>


</aside>

<aside class="contactos">
  <ul>
  <li><strong>Derechos de Copyright (C) IDEON</strong></li>
  <li><img src="imagenes/white_bar-01.png" class="bar"></li>
  <li><img src="imagenes/icons-01.png" class="icons">(011) 4558-7851</li>
  <li><img src="imagenes/white_bar-01.png" class="bar"></li>
  <li><img src="imagenes/icons-02.png" class="icons">140757</li>
  <li><img src="imagenes/white_bar-01.png" class="bar"></li>
  <li><img src="imagenes/icons-03.png" class="icons">Av.Cordoba 2012, CABA</li>
</ul>

</aside>

  <script type="text/javascript" src="js/jquery.js">

  </script>
</footer>
