@include ('vendor')
@include ('header')

  <body>

    

    </header>
    <!-- linea   -->
    <section class="linea">

    </section>


    <!-- <section class="perfil">

      <h1>Tus actividades</h1>
    </section> -->

    <br><br>



    <section class="areaT">
      <cite><p>Tus actividades</p> </cite>
      <article class="nube">
        <br>
        <p>Mis compras</p>

      </article>

      <article class="nube">
        <br>
        <p>Promociones</p>
      </article>

      <article class="nube">
        <br>
        <p>Comprar</p>
      </article>

      <article class="nube">
        <br>
        <p>Puntos</p>
      </article>
    </section>



    <br><br><br><br><br><br><br><br><br><br><br><br><br>  <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <!-- <footer class="pie">

    </footer> -->

    @include ('footer')
  </body>
</html>
