
@section('title', 'IDEON - Productos')
@section('imgurl', 'imagenes/logo-01.png')
