window.onload = function () {
    $(document).ready(function(){
        $(".flip1").click(function(){
            $(".panel1").slideToggle("slow");
        });
    });

    $(document).ready(function(){
        $(".flip2").click(function(){
            $(".panel2").slideToggle("slow");
        });
    });

    $(document).ready(function(){
        $(".flip3").click(function(){
            $(".panel3").slideToggle("slow");
        });
    });

    $(document).ready(function(){
        $(".flip4").click(function(){
            $(".panel4").slideToggle("slow");
        });
    });

    $(document).ready(function(){
        $(".flip5").click(function(){
            $(".panel5").slideToggle("slow");
        });
    });

    $(document).ready(function(){
        $(".flip6").click(function(){
            $(".panel6").slideToggle("slow");
        });
    });


    // $(document).ready(function(){
    //     $(".ask1").click(function(){
    //         $(".respuesta1").toggle();
    //     });
    // });

    // $(document).ready(function(){
    //     $(".ask2").click(function(){
    //         $(".respuesta2").toggle();
    //     });
    // });

    // $(document).ready(function(){
    //     $(".ask3").click(function(){
    //         $(".respuesta3").toggle();
    //     });
    // });

    // $(document).ready(function(){
    //     $(".ask4").click(function(){
    //         $(".respuesta4").toggle();
    //     });
    // });

    // $(document).ready(function(){
    //     $(".ask5").click(function(){
    //         $(".respuesta5").toggle();
    //     });
    // });

    // $(document).ready(function(){
    //     $(".ask6").click(function(){
    //         $(".respuesta6").toggle();
    //     });
    // });
};
