<?php $__env->startSection('title', 'IDEON - Preguntas frecuentes'); ?>
<?php $__env->startSection('imgurl', '../imagenes/logo-01.png'); ?>
