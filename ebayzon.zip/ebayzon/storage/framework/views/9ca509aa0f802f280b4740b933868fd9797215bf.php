<?php $__env->startSection('title', 'Listado de marcas'); ?>

<?php $__env->startSection('content'); ?>
	<h2>Listado de marcas</h2>
	<table class="table">
		<tr>
			<td>Name</td>
			<td>Products</td>
		</tr>
		<?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<tr>
				<td><?php echo e($oneBrand->name); ?></td>
				<td>
					<ul>
					<?php $__empty_2 = true; $__currentLoopData = $oneBrand->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
						<li><?php echo e($product->name); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
						<li>Sin productos relacionados</li>
					<?php endif; ?>
					</ul>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

		<?php endif; ?>
	</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>