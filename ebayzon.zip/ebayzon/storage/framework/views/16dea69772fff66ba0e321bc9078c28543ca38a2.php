<?php echo $__env->make('vendor', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <body>

    

    </header>
    <!-- linea   -->
    <section class="linea">

    </section>


    <!-- <section class="perfil">

      <h1>Tus actividades</h1>
    </section> -->

    <br><br>



    <section class="areaT">
      <cite><p>Tus actividades</p> </cite>
      <article class="nube">
        <br>
        <p>Mis compras</p>

      </article>

      <article class="nube">
        <br>
        <p>Promociones</p>
      </article>

      <article class="nube">
        <br>
        <p>Comprar</p>
      </article>

      <article class="nube">
        <br>
        <p>Puntos</p>
      </article>
    </section>



    <br><br><br><br><br><br><br><br><br><br><br><br><br>  <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <!-- <footer class="pie">

    </footer> -->

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>
