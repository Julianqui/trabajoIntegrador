<?php $__env->startSection('title', 'Listado de Productos'); ?>

<?php $__env->startSection('content'); ?>
	<h2>Listado de productos</h2>
	<table class="table">
		<tr>
			<td>Name</td>
			<td>Price</td>
			<td>Image</td>
			<td>Colors</td>
			<td><a href="/products?orderBy=categories">Category</a></td>
			<td><a href="/products?orderBy=brands">Brand</a></td>
		</tr>
		<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<tr>
				<td>
					<a href="<?php echo e(route('products.show', $oneProduct->id)); ?>">
						<?php echo e($oneProduct->name); ?>

					</a>
				</td>
				<td><b>$</b><?php echo e($oneProduct->price); ?></td>
				<td><img src="<?php echo e($oneProduct->image); ?>" width="100"></td>
				<td>
					<ul>
					<?php $__empty_2 = true; $__currentLoopData = $oneProduct->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
						<li><?php echo e($color->name); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
						<li>Sin colores relaciondos</li>
					<?php endif; ?>
					</ul>
				</td>
				<td><?php echo e($oneProduct->category->name ?? 'No tiene categoría'); ?></td>
				<td><?php echo e($oneProduct->brand->name ?? 'No tiene marca'); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

		<?php endif; ?>
	</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>