<?php echo $__env->make('configuracion', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>


<header>

  <a href="/libreria"><img class="isologotipo" src=<?php echo $__env->yieldContent('imgurl'); ?> alt="logo IDEON"></a>

  <nav class="secciones">


    <ul>

      <li><a href="/producto"><strong>PRODUCTOS</strong></a></li>
      <li><a href="/preguntas"><strong>PREGUNTAS FRECUENTES</strong></a></li>
      <li><a href="/fotografia"><strong>PORTAFOLIO</strong></a></li>
      <li id="registro"><a href="/registro"><strong>CREAR CUENTA</strong></a></li>
      <li id="registro_2"><a href="/acceder"><strong>ACCEDER</strong></a></li>
      <li id="registro_2"><a href="/perfil"><strong>PERFIL</strong></a></li>
    </ul>
  </nav>
