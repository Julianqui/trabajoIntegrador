function validar() {
  var usuario, email, edad, password, expresion;

  usuario = document.getElementById("apellido").value;
  email = document.getElementById("email").value;
  edad = document.getElementById("edad").value;
  password = document.getElementById("password").value;

  expresion = /\w+@\w+\.+[a-z]/;

  if( usuario === "" || email === "" || edad === "" || password === "" ){
    alert('El campo esta vacio');
    return false;
  }
  else if (usuario.length>30) {
      alert("El usuario  es muy largo");
      return false;
  }



  else if (email.length>30) {
        alert("El email es muy largo");
        return false;
    }

    else if (!expresion.test(email)) {
          alert("El email no es valido");
          return false;
      }

    else if (edad.length>2) {
          alert("Maximo dos numeros");
          return false;
      }

      else if (inNaN(edad)) {
            alert("Solo caracteres numericos");
            return false;
        }




  else if (contraseña.length>30) {
          alert("La contraseña es muy larga");
          return false;
      }
}
