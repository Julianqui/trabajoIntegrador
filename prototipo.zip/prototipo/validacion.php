<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <title></title>
  </head>
  <body>
    <script type="text/javascript" src="js/form.js"></script>
    <form action="procesar.php" method="post"  class="form-class"onsubmit="return validar(this);">
      <h2>REGISTRATE</h2>
      <input type="text" name="usuario" placeholder="Nombre de usuario"   id="nombre">

      <input type="email" name="email" placeholder="Email"  id="email">

      <label>Nacionalidad: </label>
       <select name="pais"><br> <br>

         <option value="Se">Seleccione</option>
         <option value="Ar">Argentina</option>
         <option value="Pe">Peru</option>
         <option value="Col">Colombia</option>
         <option value="Ur">Uruguay</option>
         <option value="Ec">Ecuador</option>
         <option value="Br">Brasil</option>
         <option value="Chi">Chile</option>

      <input id="edad" type="text" name="edad" placeholder="Edad" >

      <input  type="file" name="tu_foto" placeholder="Avatar" >

      <input id="password"type="password" name="password" placeholder="Contraseña" >

      <input id="rpassword" type="password" name="rpassword" placeholder="Repetir Contraseña" >

      <input type="submit" name="enviar" id="boton">

    </form>
  </body>
</html>
